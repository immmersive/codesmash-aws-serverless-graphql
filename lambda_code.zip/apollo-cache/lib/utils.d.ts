import { DocumentNode } from 'graphql';
export declare function queryFromPojo(obj: any): DocumentNode;
export declare function fragmentFromPojo(obj: any, typename?: string): DocumentNode;
export declare const justTypenameQuery: DocumentNode;
//# sourceMappingURL=utils.d.ts.map