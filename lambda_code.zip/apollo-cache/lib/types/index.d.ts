export * from './DataProxy';
export * from './Cache';
//# sourceMappingURL=index.d.ts.map