import build from '../../rollup.config';

export default build('retry');
