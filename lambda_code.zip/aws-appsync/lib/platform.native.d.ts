declare const userAgent = "react-native";
export { userAgent };
