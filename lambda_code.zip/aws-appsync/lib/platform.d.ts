declare const userAgent = "";
export { userAgent };
