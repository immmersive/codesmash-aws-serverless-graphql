---
title: apollo-link-http-common
description: Http utilities shared across Apollo Links
---

This repository is used in apollo-link-http and apollo-link-http-batch. The
package is public to allow easier development of links that will be a part of
the main repository. Developers using this package should know that the api
will change and versions may not follow SemVer.
