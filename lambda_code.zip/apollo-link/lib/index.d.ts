export * from './link';
export { createOperation, makePromise, toPromise, fromPromise, fromError, getOperationName, } from './linkUtils';
export * from './types';
import Observable from 'zen-observable-ts';
export { Observable };
//# sourceMappingURL=index.d.ts.map