export declare function getEnv(): string | undefined;
export declare function isEnv(env: string): boolean;
export declare function isProduction(): boolean;
export declare function isDevelopment(): boolean;
export declare function isTest(): boolean;
//# sourceMappingURL=environment.d.ts.map