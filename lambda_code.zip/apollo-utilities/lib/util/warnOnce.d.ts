export declare function warnOnceInDevelopment(msg: string, type?: string): void;
//# sourceMappingURL=warnOnce.d.ts.map