import { ExecutionResult } from 'graphql';
export declare function tryFunctionOrLogError(f: Function): any;
export declare function graphQLResultHasError(result: ExecutionResult): number;
//# sourceMappingURL=errorHandling.d.ts.map