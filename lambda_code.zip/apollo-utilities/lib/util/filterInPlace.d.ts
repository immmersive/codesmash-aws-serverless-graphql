export declare function filterInPlace<T>(array: T[], test: (elem: T) => boolean, context?: any): T[];
//# sourceMappingURL=filterInPlace.d.ts.map