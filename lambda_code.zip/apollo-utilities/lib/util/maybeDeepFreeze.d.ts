export declare function maybeDeepFreeze(obj: any): any;
//# sourceMappingURL=maybeDeepFreeze.d.ts.map