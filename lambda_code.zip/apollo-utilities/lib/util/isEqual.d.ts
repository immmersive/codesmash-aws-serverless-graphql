export { equal as isEqual } from '@wry/equality';
//# sourceMappingURL=isEqual.d.ts.map