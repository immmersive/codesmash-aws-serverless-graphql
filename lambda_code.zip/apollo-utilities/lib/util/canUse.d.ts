export declare const canUseWeakMap: boolean;
//# sourceMappingURL=canUse.d.ts.map