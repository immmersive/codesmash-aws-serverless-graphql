import { DocumentNode } from 'graphql';
export declare function getFragmentQueryDocument(document: DocumentNode, fragmentName?: string): DocumentNode;
//# sourceMappingURL=fragments.d.ts.map