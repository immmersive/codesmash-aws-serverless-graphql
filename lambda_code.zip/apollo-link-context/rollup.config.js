import build from '../../rollup.config';

export default build('context');
