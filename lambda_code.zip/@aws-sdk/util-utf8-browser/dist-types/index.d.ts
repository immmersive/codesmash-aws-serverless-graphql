export declare const fromUtf8: (input: string) => Uint8Array;
export declare const toUtf8: (input: Uint8Array) => string;
