export declare function fromUtf8(input: string): Uint8Array;
export declare function toUtf8(input: Uint8Array): string;
