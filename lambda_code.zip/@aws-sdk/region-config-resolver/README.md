# @aws-sdk/region-config-resolver

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/region-config-resolver/latest.svg)](https://www.npmjs.com/package/@aws-sdk/region-config-resolver)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/region-config-resolver.svg)](https://www.npmjs.com/package/@aws-sdk/region-config-resolver)

> An internal package

This package provides utilities for AWS region config resolvers.

## Usage

You probably shouldn't, at least directly.
