/**
 * @internal
 */
export declare const getRealRegion: (region: string) => string;
