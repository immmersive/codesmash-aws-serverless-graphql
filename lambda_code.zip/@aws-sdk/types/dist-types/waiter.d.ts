export { WaiterConfiguration } from "@smithy/types";
