import { Identity } from "./Identity";
/**
 * @public
 */
export interface AnonymousIdentity extends Identity {
}
