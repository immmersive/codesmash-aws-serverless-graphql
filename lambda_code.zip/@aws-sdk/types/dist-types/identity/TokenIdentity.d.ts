export { TokenIdentity, TokenIdentityProvider } from "@smithy/types";
