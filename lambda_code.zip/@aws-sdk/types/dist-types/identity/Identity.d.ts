export { Identity, IdentityProvider } from "@smithy/types";
