export { EndpointARN, EndpointPartition, EndpointURLScheme, EndpointURL, EndpointObjectProperty, EndpointV2, EndpointParameters, } from "@smithy/types";
