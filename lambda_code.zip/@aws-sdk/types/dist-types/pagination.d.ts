export { PaginationConfiguration, Paginator } from "@smithy/types";
