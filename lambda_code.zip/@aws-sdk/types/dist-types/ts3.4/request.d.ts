export interface Request {
  destination: URL;
  body?: any;
}
