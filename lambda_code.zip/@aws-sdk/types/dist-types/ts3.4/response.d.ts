export { MetadataBearer, ResponseMetadata } from "@smithy/types";
export interface Response {
  body: any;
}
