export {
  AuthScheme,
  HttpAuthDefinition,
  HttpAuthLocation,
} from "@smithy/types";
