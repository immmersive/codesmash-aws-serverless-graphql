import { AwsSdkFeatures } from "@aws-sdk/types";
export declare function encodeFeatures(features: AwsSdkFeatures): string;
